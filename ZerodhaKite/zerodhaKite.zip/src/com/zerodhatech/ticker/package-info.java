/**Websocket connection related components for getting live quotes.*/
package com.zerodhatech.ticker;