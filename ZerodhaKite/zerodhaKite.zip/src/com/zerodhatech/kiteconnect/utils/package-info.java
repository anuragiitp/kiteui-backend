/**Commonly used constants are defined here.*/
package com.zerodhatech.kiteconnect.utils;