/**Wrapper classes for making API call to server and callback for session expiry event.*/
package com.zerodhatech.kiteconnect.kitehttp;