/**Different exceptions that kite connect deals with.*/
package com.zerodhatech.kiteconnect.kitehttp.exceptions;