
public class SymbolQty{
	public SymbolQty(String tradingSymbol,String exchange,int quantity){
		this.tradingSymbol=tradingSymbol;
		this.exchange=exchange;
		this.quantity=quantity;
	}
	public String tradingSymbol;
	public int quantity;
	public String exchange;
}